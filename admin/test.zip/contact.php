<?php

include('database.php');
include("header.php");
include("sidebar.php");


?>

<html>
<head>
	<style>
	.dtHorizontalExampleWrapper {
		max-width: 600px;
		margin: 0 auto;
	}
	#dtHorizontalExample th, td {
		white-space: nowrap;
	}

	table.dataTable thead .sorting:after,
	table.dataTable thead .sorting:before,
	table.dataTable thead .sorting_asc:after,
	table.dataTable thead .sorting_asc:before,
	table.dataTable thead .sorting_asc_disabled:after,
	table.dataTable thead .sorting_asc_disabled:before,
	table.dataTable thead .sorting_desc:after,
	table.dataTable thead .sorting_desc:before,
	table.dataTable thead .sorting_desc_disabled:after,
	table.dataTable thead .sorting_desc_disabled:before {
		bottom: .5em;
	}
	.text{
		color: white
	}
</style>

<script>
	$(document).ready(function () {
		$('#dtHorizontalExample').DataTable({
			"scrollX": true
		});
		$('.dataTables_length').addClass('bs-select');
	});
</script>

</head>
</html>
<!-- Main content -->
<div class="content-wrapper">

	<!-- Page header -->
	<div class="page-header page-header-light">
		<div class="page-header-content header-elements-md-inline">
			<div class="page-title d-flex">
				<a href="categories_panel.php" class="breadcrumb-item"><i class="icon-home2 mr-2"></i>Admin Panel</a>
				<span class="breadcrumb-item active"> Contact</span>
			</div>

			<div class="header-elements d-none">

			</div>
		</div>


	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">

		<div class="row">
			<div class="col-xl-12">

				<div class="card">
					<div class="row">
						<div class="col-md-6">
							<h2 class="p-3"></h2>
							
						</div>
						<div class="col-md-6 text-right ">
							<button style="    margin-right: 20px;" type="button" class="btn btn-success mt-3" data-toggle="modal" data-target="#myModal">Add Contact</button>
						</div>
					</div>
					<div class="table-responsive">
						<table id="dtHorizontalExample" class="table table-striped table-bordered table-sm text-center" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>Id</th>
									<th>First Name</th>
									<th>Last Name</th>
									<th>Email</th>
									<th>Subject</th>
									<th>Message</th> 
									<th>Edit</th>
									<th>Delete</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>1</td>
									<td>jack</td>
									<td>Mark</td>
									<td>jack@gmail.com</td>
									<td>Test</td>
									<td>Lorem Ipusm</td>
									<td><a href="#!"><i class="fas fa-edit text-dark" data-toggle="modal" data-target="#part" ></i></a></td>
									<td><a href="#!"><i class="fas fa-trash text-dark"></i></a></td>
								</tr>

								<tr>
									<td>2</td>
									<td>jack</td>
									<td>Mark</td>
									<td>jack@gmail.com</td>
									<td>Test</td>
									<td>Lorem Ipusm</td>
									<td><a href="#!"><i class="fas fa-edit text-dark" data-toggle="modal" data-target="#part" ></i></a></td>
									<td><a href="#!"><i class="fas fa-trash text-dark"></i></a></td>
								</tr>

								<tr>
									<td>3</td>
									<td>jack</td>
									<td>Mark</td>
									<td>jack@gmail.com</td>
									<td>Test</td>
									<td>Lorem Ipusm</td>
									<td><a href="#!"><i class="fas fa-edit text-dark" data-toggle="modal" data-target="#part" ></i></a></td>
									<td><a href="#!"><i class="fas fa-trash text-dark"></i></a></td>
								</tr>

								<tr>
									<td>4</td>
									<td>jack</td>
									<td>Mark</td>
									<td>jack@gmail.com</td>
									<td>Test</td>
									<td>Lorem Ipusm</td>
									<td><a href="#!"><i class="fas fa-edit text-dark" data-toggle="modal" data-target="#part" ></i></a></td>
									<td><a href="#!"><i class="fas fa-trash text-dark"></i></a></td>
								</tr>
							</tbody>
						</table>
					</div>



				</div>
				<!-- /support tickets -->


			</div>


		</div>


	</div>



	<!-- Modal -->
	<div class="modal fade" id="myModal" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header" style="background-color: black">
					<div class="row">
						<div class="col-md-12">
							<div class="text">
								<h4 class="modal-title mb-3">Add Contact</h4>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-12">
							<h5 >First Name</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your name">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2">Last Name</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your Last name">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2" >Email</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your Email">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2">Subject</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your Subject">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2">Message</h5>
							<input class="form-control" type="text" name="" placeholder="Message">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 text-center mt-3">
							<button type="button" class="btn btn-success text-center" data-dismiss="modal">Submit</button>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>


	<div class="modal fade" id="part" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header" style="background-color: black">
					<div class="row">
						<div class="col-md-12">
							<div class="text">
								<h4 class="modal-title mb-3">Update Contact</h4>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-12">
							<h5 >First Name</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your name">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2">Last Name</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your Last name">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2" >Email</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your Email">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2">Subject</h5>
							<input class="form-control" type="text" name="" placeholder="Enter your Subject">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h5 class="mt-2">Message</h5>
							<input class="form-control" type="text" name="" placeholder="Message">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 text-center mt-3">
							<button type="button" class="btn btn-success text-center" data-dismiss="modal">Submit</button>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<script>
		function deleteit(){
			return(confirm("The record will be deleted permanently. Do you really want to continue?"));
		}
		function editit(){
			return(confirm("Do you want to edit?"));
		}
	</script>

	<?php

	include("footer.php");            

	?>
