<!-- Footer -->
			<div class="navbar navbar-expand-lg navbar-light">
				<div class="text-center d-lg-none w-100">
					<button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse" data-target="#navbar-footer">
						<i class="icon-unfold mr-2"></i>
						Footer
					</button>
				</div>

				<div class="navbar-collapse collapse" id="navbar-footer">
					<span class="navbar-text">
                        <a>Designed </a>and <a>Developed</a> by <a href="http://ateccotechnologies.com/" target="_blank">Atecco Technologies.</a>
					</span>

					 
				</div>
			</div>
			<!-- /footer -->

</div>
		<!-- /main content -->

	</div>
	<!-- /page content -->

</body>

</html>
