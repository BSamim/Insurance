<?php
session_start();
$admin = $_SESSION['email'];
require_once("database.php");
$db = db::open();
$datee = date("d-m-Y");
                // all insertion code start
if(isset($_POST['login']))
{
    $email=$_POST['username'];
    $password=$_POST['password'];
    
    $query="SELECT * from admin where email='$email' && password='$password'";
    $rec=db::getRecord($query);
    
    if($rec!=NULL)
    {  
        
        $_SESSION['email']=$email;
        echo "<script>location='dashboard.php'</script>";
    }
    else
    {
       echo "<script>location='index.php?status=1'</script>";
    }
}
//update admin
if (isset($_POST['update'])) 
{
    $name=$_POST['name'];
    $password=$_POST['password'];
    
    if($_FILES['doc_file']['name']=="")
    {
      $sql2 = "UPDATE admin SET name='$name',password='$password'";
      $r = db::query($sql2);
      echo "<script>location='profile.php?status=1'</script>";  
    }else
    {   
            $file = rand(1000,100000)."-".$_FILES['doc_file']['name'];
            $file_loc = $_FILES['doc_file']['tmp_name'];
            $file_size = $_FILES['doc_file']['size'];
            $file_type = $_FILES['doc_file']['type'];
            $folder ="uploads/";
            $new_file_name = strtolower($file);
            $final_file=str_replace(' ','-',$new_file_name);
            $a = move_uploaded_file($file_loc,$folder.$final_file);
            $sql2 = "UPDATE admin SET name='$name',password='$password',image='$final_file'";
            $r = db::query($sql2);
             echo "<script>location='profile.php?status=1'</script>";

    }
}

//logout
if(isset($_GET['logout']))
{
  unset($_SESSION['email']);
   echo "<script>location='index.php'</script>";
}

//delete_viewer
if(isset($_GET['delete_viewer']))
{
    $id = $_GET['delete_viewer'];

     $sql = "DELETE FROM user WHERE id='$id'";
    db::query($sql);
    echo "<script>location='viewers.php'</script>";
}



?>